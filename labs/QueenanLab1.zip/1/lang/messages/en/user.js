const messages = {
    add : 'Add',
    remove : 'Remove',
    back : 'Back to Home',
    title : 'Reading and Writing App - Catherine Queenan',
    writer : 'Write Notes',
    reader : 'Read Notes',
    updateTime : 'Last Updated at: ',
    storeTime : 'Stored at: ',
    enterNote : 'Enter Note Text Here',
}