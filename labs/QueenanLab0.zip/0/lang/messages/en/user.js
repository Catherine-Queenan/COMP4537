window.userMessages = {
    invalidInput: () => "Please enter a number between 3 and 7",
    gameWin: () => "Excellent memory!",
    gameLose: () => "Wrong order!",
    inputBox: () => "Enter number between 3 & 7",
    boxLabel: () => "How many buttons to create?",
    goButton: () => "Go!",
}