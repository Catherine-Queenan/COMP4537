const http = require("http");
const ServerInfo = require("./modules/utils");

class Server {
    constructor(port) {
        this.port = port || 8080;
        this.serverInfo = new ServerInfo();
    }

    handleRequest(req, res) {
        this.serverInfo.handleRequest(req, res); // Pass `res` to avoid errors
    }

    start() {
        const server = http.createServer((req, res) => this.handleRequest(req, res));
        server.listen(this.port, () => {
            
        });
    }
}

const app = new Server(8080);
app.start();
