module.exports = {
    greeting : "Hello %1, What a beautiful day. Server current date and time is %2",
    guest : "Guest",
    error : "404 Not Found",
    errorFile : "404 Not Found: The file: %1 does not exist.",
    errorText : "Error: No text provided to append.",
    fileError : "Error writing to file: %1",
    successText : "Text %1 appended to file.txt",
}